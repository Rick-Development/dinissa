


class ApiUrl {
  static const String baseUrl = 'https://dinissa.com.ng/api'; // Replace with your base URL
  static const String login = '$baseUrl/user/login';
  static const String signup = '$baseUrl/user/registration';
  static const String csrfToken = '';
}
