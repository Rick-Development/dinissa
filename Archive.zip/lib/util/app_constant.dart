class AppConstants {
  static String appName = 'Dinissa';

  // static dynamic primaryColor = Color(0xFFFFE072);
  // static dynamic secondaryColor = Colors.blue;
}
