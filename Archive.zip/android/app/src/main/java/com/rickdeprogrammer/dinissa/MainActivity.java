package com.rick.dinissa; // Ensure this matches your package name

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
