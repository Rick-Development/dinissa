package com.rick.dinissa.dinissa

//
//class MainActivity: FlutterActivity()
