
import 'package:flutter/material.dart';

const AppName = 'Dinissa';

class AppConstants{

  static dynamic primaryColor = Color(0xFFFFE072);
  static dynamic secondaryColor = Colors.blue;
}