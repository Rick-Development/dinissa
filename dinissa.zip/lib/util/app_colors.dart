import 'package:flutter/material.dart';



class AppColors{
  static final primaryColor = Color(0xFFFEBD59);
  static final secondaryColor = Color(0xFF004AAC);
}