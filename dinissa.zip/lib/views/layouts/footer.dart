import 'package:flutter/material.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import '../../routes/app.dart';
import '../../util/app_colors.dart';

class Footer extends StatefulWidget {
  final int initialIndex;

  const Footer({Key? key, required this.initialIndex}) : super(key: key);

  @override
  _FooterState createState() => _FooterState();
}

class _FooterState extends State<Footer> {
  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _currentIndex = widget.initialIndex;
  }

  @override
  Widget build(BuildContext context) {
    return CurvedNavigationBar(
      backgroundColor: AppColors.primaryColor,
      height: 60,
      index: _currentIndex,
      items: <Widget>[
        _buildNavItem(Icons.home, 'Home', 0),
        _buildNavItem(Icons.currency_exchange, 'P2P', 1),
        _buildNavItem(Icons.account_balance_wallet, 'Loan & Save', 2),
        _buildNavItem(Icons.person, 'Profile', 3),
      ],
      onTap: (index) {
        setState(() {
          _currentIndex = index;
        });
        switch (index) {
          case 0:
            Navigator.pushReplacementNamed(context, AppRoutes.home);
            break;
          case 1:
            Navigator.pushReplacementNamed(context, AppRoutes.p2p);
            break;
          case 2:
            Navigator.pushReplacementNamed(context, AppRoutes.loanSave);
            break;
          case 3:
            Navigator.pushReplacementNamed(context, AppRoutes.profile);
            break;
        }
      },
    );
  }

  Widget _buildNavItem(IconData icon, String text, int index) {
    final isActive = index == _currentIndex;
    final formattedText = isActive ? text.split(" ").join("\n&\n") : text;

    final Widget _text = isActive ? SizedBox() : Text(
      formattedText,
      textAlign: TextAlign.center,
      style: TextStyle(
        fontSize: 10,
        color: isActive ? Colors.white : Colors.grey,
      ),
    );

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, size: 20),
        SizedBox(height: 4),
        _text,
      ],
    );
  }
}
