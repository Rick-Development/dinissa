import 'package:dinissa/util/app_constant.dart';
import 'package:dinissa/views/home_screen.dart';
import 'package:dinissa/views/signup_screen.dart';
import 'package:flutter/material.dart';

import '../util/app_colors.dart';


class LoginScreen extends StatefulWidget{
  @override
  State<LoginScreen> createState() => _loginScreen();
}

class _loginScreen extends State<LoginScreen>{
  @override
  Widget build(BuildContext context) {
    return(
    Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.primaryColor,
        foregroundColor: Colors.black,
      ),
      body: Container(
        color: AppColors.secondaryColor,
      child: Column(

          children: [
            // Image.asset("assets/images/Sun.png",
            // width: MediaQuery.of(context).size.width,
            //   fit: BoxFit.fill,
            // ),
            Image.asset("assets/images/undraw_walking_in_rain_vo9p 2.png",
            height: MediaQuery.of(context).size.height * 0.30,
            ),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 10.0),
              child: Text(AppName,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 25,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.0),
              child: Column(
                children: [

                  _buildInputField(
                    // controller: _emailController,
                    labelText: 'Email',
                    prefixIcon: Icons.email,
                    keyboardType: TextInputType.emailAddress,
                  ),

                  SizedBox(height: 20.0),
                  _buildInputField(
                    // controller: null,
                    labelText: 'Password',
                    prefixIcon: Icons.lock,
                    obscureText: true,
                  ),
                  SizedBox(height: 20.0),
              Container(
                height: 40, // Adjust the height as needed
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16.0),
                  border: Border.all(color: Colors.grey),
                ),
                child:Container(
                  width: MediaQuery.of(context).size.width * 0.9, // 90% of screen width
                  child: FloatingActionButton.extended(
                    onPressed: () {
                      Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => HomeScreen()),
                      );
                    },
                    label: Text('Login'), // Use label instead of child for extended button
                    backgroundColor: AppColors.primaryColor, // Background color
                    foregroundColor: Colors.black, // Color of the text/icon
                    shape: RoundedRectangleBorder( // Shape of the button
                      borderRadius: BorderRadius.circular(8.0), // Rounded corners
                    ),
                    elevation: 5.0, // Elevation of the button
                  ),
                ),
              ),
                  SizedBox(height: 10.0),
                  GestureDetector(
                    onTap: ()=>{
                    Navigator.of(context).pushReplacement(
                    MaterialPageRoute(builder: (_) => SignupScreen()),
                    )
                    },
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "New User ? ",
                          style: TextStyle(
                            color: Colors.white,
                          ),
                        ),
                        Text(
                          "Signup",
                          style: TextStyle(
                            color: AppColors.primaryColor,
                          ),
                        ),
                      ],
                    )
                  )

                ],
              ),
            ),
          ],
        ),
      )
    )
    );
  }

}
Widget _buildInputField({
  required String labelText,
  required IconData prefixIcon,
  bool obscureText = false,
  TextInputType keyboardType = TextInputType.text,
}) {
  return Container(
    height: 40, // Adjust the height as needed
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(16.0),
      border: Border.all(color: Colors.grey),
    ),
    child: TextFormField(
      style: TextStyle(
        fontSize: 14,
        color: Colors.white, // Set text color to white
      ),
      // controller: controller,
      decoration: InputDecoration(
        contentPadding: EdgeInsets.symmetric(vertical: 8), // Adjust the content padding as needed
        labelText: labelText,
        labelStyle: TextStyle(color: Colors.white), // Set label text color to white
        prefixIcon: Icon(prefixIcon, color: Colors.white), // Set prefix icon color to white
        border: InputBorder.none,
      ),
      obscureText: obscureText,
      keyboardType: keyboardType,
    ),
  );
}
